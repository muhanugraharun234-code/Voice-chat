# Position bridge protocol

The add-on runs inside the Bedrock client and does not have unrestricted socket access. For automatic proximity audio, a dedicated Bedrock server extension must read authoritative player positions and publish them to the signaling service.

Connect:
`wss://YOUR-HOST/bridge?token=YOUR_BRIDGE_TOKEN`

Send at a modest interval (e.g. 5–10 updates/second per player):
```json
{"type":"position","room":"ABC123","playerId":"stable-id","x":12.5,"y":64,"z":-3,"dimension":"overworld"}
```
Use stable IDs that map to the companion-app participants. Never trust arbitrary client-supplied positions in public competitive servers. The included Node server authenticates the bridge with a shared secret but does not implement a Bedrock Dedicated Server plugin.
