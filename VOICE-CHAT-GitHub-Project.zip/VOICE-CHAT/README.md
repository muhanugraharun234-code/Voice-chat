# VOICE CHAT — Minecraft Bedrock 1.26 + Android companion

This repository contains:
- `addon/VOICE-CHAT.mcaddon`: Bedrock behavior/resource pack bundle.
- `android/`: Android companion APK source (WebView + WebRTC browser APIs).
- `server/`: Node.js WebSocket signaling server.
- `.github/workflows/android.yml`: GitHub Actions APK build.

## Important architecture note

A Bedrock add-on cannot access the phone microphone or create arbitrary WebRTC audio sessions. The Android app handles microphone capture and real-time audio. The add-on provides in-game controls/instructions and room-code display.

**Global voice** works between users who install the companion APK and connect to the same signaling server + room.

**Proximity voice** additionally needs a trusted server-side position bridge that sends each player's Minecraft coordinates to the signaling server. A normal client-side `.mcaddon` cannot read another player's live position in the companion app or open an unrestricted network socket. This repository includes the bridge protocol and server endpoint; it does not pretend that the add-on alone supplies that missing integration. A dedicated-server extension/bridge must be deployed for automatic position sync.

## Quick start

### 1. Build APK with GitHub Actions
1. Create a new GitHub repository and upload the contents of this folder.
2. Open **Actions** and run **Build Android APK** (or push to `main`).
3. Download the `voice-chat-debug-apk` artifact.
4. Install `app-debug.apk` on Android and allow microphone permission.

### 2. Run signaling server
Requires Node.js 20+:
```bash
cd server
npm install
npm start
```
Set `PORT` (default 8080) and `BRIDGE_TOKEN` before exposing it publicly.
For internet use, deploy behind HTTPS/WSS (for example a reverse proxy with TLS). The app's default server URL is a placeholder; enter your own `wss://host/ws` endpoint in the app.

### 3. Install Bedrock add-on
Import `addon/VOICE-CHAT.mcaddon` into Minecraft Bedrock 1.26.
Activate **VOICE CHAT BP** in Behavior Packs. The resource pack is included for pack identity and UI textures.
In chat, type `!voice` to open the in-game guide. Type `!voice room ABC123` to save/display a room code.

## Signaling protocol
Client messages are JSON:
- `join`: `{type:"join", room:"ABC123", name:"Player", mode:"global"|"proximity"}`
- `offer`, `answer`, `ice`: WebRTC signaling relay.
- `leave`
- `position`: bridge-only `{type:"position", playerId:"...", x:0,y:0,z:0, dimension:"overworld"}`

Bridge connection:
- Connect to `/bridge?token=YOUR_BRIDGE_TOKEN`.
- Send `{type:"position", playerId:"stable-player-id", room:"ABC123", x:0,y:0,z:0, dimension:"overworld"}`.
- The server broadcasts position updates to clients in the same room.
The app attenuates/mutes peers outside the configured radius when valid positions are available. Until a real server bridge is connected, proximity mode displays a clear "waiting for position bridge" state.

## Security
- Use TLS (`wss://`) for public deployment.
- Set a long random `BRIDGE_TOKEN`.
- Do not expose the bridge endpoint without authentication.
- The included signaling server is a small prototype; add rate limiting, room limits, TURN service and moderation before public production use.
