import { world } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";

const KEY = "voice_chat_room";
const PREFIX = "§8[§bVOICE CHAT§8]§r ";

function showHelp(player) {
  const room = player.getDynamicProperty(KEY) || "Belum diatur";
  new ActionFormData()
    .title("§l§bVOICE CHAT")
    .body(
      "§fCompanion Android diperlukan untuk audio.\n\n" +
      "§7Room tersimpan: §a" + room + "\n" + "§7Minecraft Player ID: §e" + player.id + "\n\n" +
      "§f1. Buka aplikasi VOICE CHAT di Android.\n" +
      "§f2. Masukkan server signaling dan room yang sama.\n" +
      "§f3. Izinkan akses mikrofon.\n" + "§f4. Salin Player ID di atas ke aplikasi untuk proximity.\n\n" +
      "§eGlobal: semua pemain dalam room.\n" +
      "§eProximity: perlu position bridge pada server."
    )
    .button("Atur kode room")
    .button("Tutup")
    .show(player)
    .then((result) => {
      if (result.canceled || result.selection !== 0) return;
      new ModalFormData()
        .title("Kode Room VOICE CHAT")
        .textField("Kode room (contoh: ABC123)", "ABC123", String(room === "Belum diatur" ? "" : room))
        .show(player)
        .then((form) => {
          if (form.canceled) return;
          const value = String(form.formValues?.[0] || "").trim().toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 20);
          if (!value) {
            player.sendMessage(PREFIX + "Kode room kosong.");
            return;
          }
          player.setDynamicProperty(KEY, value);
          player.sendMessage(PREFIX + "Kode room disimpan: §a" + value);
          player.sendMessage(PREFIX + "Masukkan kode yang sama di aplikasi Android.");
        });
    });
}

world.afterEvents.chatSend.subscribe((event) => {
  const message = event.message.trim();
  if (message === "!voice" || message === "!voice help") {
    showHelp(event.sender);
    return;
  }
  if (message.toLowerCase().startsWith("!voice room ")) {
    const value = message.substring(12).trim().toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 20);
    if (!value) {
      event.sender.sendMessage(PREFIX + "Gunakan: !voice room KODE");
      return;
    }
    event.sender.setDynamicProperty(KEY, value);
    event.sender.sendMessage(PREFIX + "Room disimpan: §a" + value);
    event.sender.sendMessage(PREFIX + "Buka aplikasi Android dan gunakan kode yang sama.");
  }
});
