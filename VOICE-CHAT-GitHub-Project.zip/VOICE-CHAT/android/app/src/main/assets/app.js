const $ = id => document.getElementById(id);
let socket=null, localStream=null, selfId=null, micOn=false, peers=new Map(), members=new Map(), positions=new Map();
let roomJoined=false, gamePlayerId=null;
const pcConfig={iceServers:[{urls:"stun:stun.l.google.com:19302"}]};
function setStatus(text,online=false){$("status").textContent=text;$("status").style.color=online?"#72efc0":"#ffb3a5";}
function render(){
  $("count").textContent=members.size+" online";
  const host=$("members");host.innerHTML="";
  if(!members.size){host.innerHTML='<p class="empty">Belum ada pemain lain di room.</p>';return;}
  for(const [id,m] of members){const d=document.createElement("div");d.className="member";d.innerHTML=`<span>${escapeHtml(m.name||"Player")}${id===selfId?" (Kamu)":""}</span><small>${id===selfId?"YOU":"CONNECTED"}</small>`;host.appendChild(d);}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function send(obj){if(socket&&socket.readyState===WebSocket.OPEN)socket.send(JSON.stringify(obj));}
async function connect(){
  if(roomJoined){disconnect();return;}
  const url=$("server").value.trim(), room=$("room").value.trim().toUpperCase(), name=$("name").value.trim()||"Player", gameId=$("gameId").value.trim();
  if(!url.startsWith("wss://")&&!url.startsWith("ws://")){alert("Masukkan URL WebSocket ws:// atau wss://");return;}
  if(!room){alert("Isi kode room terlebih dahulu.");return;}
  $("connect").disabled=true;
  try{
    localStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});
    localStream.getAudioTracks().forEach(t=>t.enabled=false);
    socket=new WebSocket(url);
    socket.onopen=()=>{gamePlayerId=gameId||null;send({type:"join",room,name,playerId:gamePlayerId,mode:$("mode").value});$("connect").textContent="LEAVE ROOM";$("connect").disabled=false;roomJoined=true;setStatus("CONNECTED",true);$("mic").disabled=false;members.set(selfId||"self",{name});render();};
    socket.onmessage=async e=>{try{await handle(JSON.parse(e.data));}catch(err){console.error(err);}};
    socket.onerror=()=>{setStatus("ERROR");$("hint").textContent="Koneksi gagal. Periksa URL server, TLS, dan jaringan."};
    socket.onclose=()=>{if(roomJoined)disconnect(false);};
  }catch(e){$("connect").disabled=false;alert("Akses mikrofon/koneksi gagal: "+e.message);stopLocal();}
}
function stopLocal(){if(localStream){localStream.getTracks().forEach(t=>t.stop());localStream=null;}}
function disconnect(closeSocket=true){
  roomJoined=false;micOn=false;$("mic").textContent="MICROPHONE: MUTED";$("mic").disabled=true;$("connect").textContent="CONNECT TO ROOM";$("connect").disabled=false;setStatus("OFFLINE");
  for(const pc of peers.values())pc.close();peers.clear();members.clear();positions.clear();render();stopLocal();
  if(closeSocket&&socket){const s=socket;socket=null;s.close();}else socket=null;
}
async function makePeer(id,initiator){
  if(peers.has(id))return peers.get(id);
  const pc=new RTCPeerConnection(pcConfig);peers.set(id,pc);
  localStream?.getTracks().forEach(t=>pc.addTrack(t,localStream));
  pc.onicecandidate=e=>{if(e.candidate)send({type:"ice",to:id,candidate:e.candidate});};
  pc.ontrack=e=>{let audio=document.getElementById("audio-"+id);if(!audio){audio=document.createElement("audio");audio.id="audio-"+id;audio.autoplay=true;document.body.appendChild(audio);}audio.srcObject=e.streams[0];updatePeerVolume(id);};
  pc.onconnectionstatechange=()=>{if(["failed","closed"].includes(pc.connectionState)){pc.close();peers.delete(id);}};
  if(initiator){const offer=await pc.createOffer();await pc.setLocalDescription(offer);send({type:"offer",to:id,sdp:offer});}
  return pc;
}
async function handle(m){
  if(m.type==="welcome"){selfId=m.id;members.set(selfId,{name:$("name").value||"Player",playerId:gamePlayerId});render();return;}
  if(m.type==="peers"){for(const p of m.peers||[]){members.set(p.id,p);await makePeer(p.id,true);}render();return;}
  if(m.type==="peer-joined"){members.set(m.id,{name:m.name,playerId:m.playerId||null});render();return;}
  if(m.type==="peer-left"){members.delete(m.id);peers.get(m.id)?.close();peers.delete(m.id);document.getElementById("audio-"+m.id)?.remove();positions.delete(m.id);render();return;}
  if(m.type==="offer"){const pc=await makePeer(m.from,false);await pc.setRemoteDescription(m.sdp);const answer=await pc.createAnswer();await pc.setLocalDescription(answer);send({type:"answer",to:m.from,sdp:answer});return;}
  if(m.type==="answer"){const pc=peers.get(m.from);if(pc)await pc.setRemoteDescription(m.sdp);return;}
  if(m.type==="ice"){const pc=peers.get(m.from);if(pc&&m.candidate)await pc.addIceCandidate(m.candidate);return;}
  if(m.type==="position"){positions.set(m.playerId,{x:m.x,y:m.y,z:m.z,dimension:m.dimension});updateAllVolumes();return;}
  if(m.type==="error"){alert(m.message||"Server error");}
}
function updatePeerVolume(id){
  const mode=$("mode").value;if(mode==="global")return;
  const a=document.getElementById("audio-"+id);if(!a)return;
  const other=positions.get(members.get(id)?.playerId||id), self=positions.get(gamePlayerId||selfId);
  if(!other||!self){a.volume=1;$("hint").textContent="Proximity menunggu position bridge dan Minecraft Player ID yang cocok. Audio sementara tidak difilter.";return;}
  if(other.dimension!==self.dimension){a.volume=0;return;}
  const d=Math.hypot(other.x-self.x,other.y-self.y,other.z-self.z),r=Number($("radius").value);
  a.volume=Math.max(0,Math.min(1,1-d/r)); 
}
function updateAllVolumes(){for(const id of peers.keys())updatePeerVolume(id);}
$("connect").onclick=connect;
$("mic").onclick=()=>{if(!localStream)return;micOn=!micOn;localStream.getAudioTracks().forEach(t=>t.enabled=micOn);$("mic").textContent="MICROPHONE: "+(micOn?"LIVE":"MUTED");};
$("radius").oninput=()=>{$("radiusText").textContent=$("radius").value+" blok";updateAllVolumes();};
$("mode").onchange=()=>{if(roomJoined)send({type:"mode",mode:$("mode").value});updateAllVolumes();};
window.addEventListener("beforeunload",()=>disconnect());
