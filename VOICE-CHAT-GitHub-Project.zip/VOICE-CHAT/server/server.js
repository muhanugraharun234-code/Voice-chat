import { WebSocketServer, WebSocket } from "ws";
import { createServer } from "node:http";
import { randomUUID, timingSafeEqual } from "node:crypto";
import { URL } from "node:url";

const PORT = Number(process.env.PORT || 8080);
const BRIDGE_TOKEN = process.env.BRIDGE_TOKEN || "";
const server = createServer((req,res)=>{
  if(req.url==="/health"){res.writeHead(200,{"content-type":"application/json"});res.end(JSON.stringify({ok:true,service:"voice-chat-signaling"}));return;}
  res.writeHead(404);res.end("Not found");
});
const wss = new WebSocketServer({noServer:true});
const rooms = new Map();
const positions = new Map();
function safeEqual(a,b){const aa=Buffer.from(a),bb=Buffer.from(b);return aa.length===bb.length&&timingSafeEqual(aa,bb);}
function send(ws,obj){if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(obj));}
function roomPeers(room,exclude){return [...(rooms.get(room)?.values()||[])].filter(p=>p.ws!==exclude);}
function broadcast(room,obj,exclude){for(const p of rooms.get(room)?.values()||[])if(p.ws!==exclude)send(p.ws,obj);}
server.on("upgrade",(req,socket,head)=>{
  const url=new URL(req.url,"http://localhost");
  const isBridge=url.pathname==="/bridge";
  if(url.pathname!=="/ws"&&!isBridge){socket.destroy();return;}
  if(isBridge&&(!BRIDGE_TOKEN||!safeEqual(url.searchParams.get("token")||"",BRIDGE_TOKEN))){socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n");socket.destroy();return;}
  wss.handleUpgrade(req,socket,head,ws=>{ws.isBridge=isBridge;wss.emit("connection",ws,req);});
});
wss.on("connection",(ws)=>{
  ws.id=randomUUID();ws.room=null;ws.isBridge=!!ws.isBridge;
  send(ws,{type:"welcome",id:ws.id});
  ws.on("message",(raw)=>{
    let m;try{m=JSON.parse(raw.toString());}catch{return send(ws,{type:"error",message:"Invalid JSON"});}
    if(ws.isBridge){
      if(m.type==="position"&&typeof m.room==="string"&&typeof m.playerId==="string"&&[m.x,m.y,m.z].every(Number.isFinite)){
        const item={type:"position",playerId:m.playerId,x:m.x,y:m.y,z:m.z,dimension:String(m.dimension||"overworld")};
        positions.set(m.room+":"+m.playerId,item);broadcast(m.room,item);return;
      }
      return;
    }
    if(m.type==="join"){
      const room=String(m.room||"").toUpperCase().replace(/[^A-Z0-9_-]/g,"").slice(0,20);
      const name=String(m.name||"Player").slice(0,18);
      if(!room)return send(ws,{type:"error",message:"Room code required"});
      if(ws.room){rooms.get(ws.room)?.delete(ws.id);}
      ws.room=room;ws.name=name;ws.playerId=String(m.playerId||ws.id).slice(0,128);ws.mode=["global","proximity","both"].includes(m.mode)?m.mode:"global";
      if(!rooms.has(room))rooms.set(room,new Map());
      const peers=roomPeers(room,ws).map(p=>({id:p.ws.id,name:p.name||"Player",playerId:p.playerId||null}));
      rooms.get(room).set(ws.id,{ws,name,mode:ws.mode});
      send(ws,{type:"peers",peers});
      broadcast(room,{type:"peer-joined",id:ws.id,name,playerId:ws.playerId},ws);
      for(const [key,pos] of positions)if(key.startsWith(room+":"))send(ws,pos);
      return;
    }
    if(m.type==="leave"){leave(ws);return;}
    if(m.type==="mode"){if(ws.room&&rooms.get(ws.room)?.has(ws.id))rooms.get(ws.room).get(ws.id).mode=m.mode;return;}
    if(["offer","answer","ice"].includes(m.type)&&ws.room&&typeof m.to==="string"){
      const target=rooms.get(ws.room)?.get(m.to);if(target)send(target.ws,{...m,from:ws.id});return;
    }
  });
  ws.on("close",()=>leave(ws));
});
function leave(ws){
  if(!ws.room)return;
  const room=ws.room;rooms.get(room)?.delete(ws.id);
  broadcast(room,{type:"peer-left",id:ws.id});
  if(rooms.get(room)?.size===0)rooms.delete(room);
  ws.room=null;
}
server.listen(PORT,"0.0.0.0",()=>console.log(`VOICE CHAT signaling listening on ${PORT}`));
